/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

/******************************************************************************

          Lenguajes de Programación I
Actividad 2. Operaciones Básicas en C++
Escenario
Actividad 2. Suma, Resta, Multiplicación y División
Contextualización:
Generar un programa que realice lo siguiente:
1. Que pida el ingreso de dos valores (ya sean enteros o decimales).
2. Que los sume, reste, multiplique y divida.
3. Que los muestre en pantalla con su respectivo enunciado.
Para ello, se debe tener en cuenta la siguiente estructura de impresión de datos:
Escribe el primer número:
Escribe el segundo número:
La suma es:
La resta es:
La multiplicación es:
La división es:


*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    float x,y,suma,resta,multiplicacion,division;
    
    cout<<"ingresar primer numero entero o decimal    ";cin>>x;
    cout<<"ingresar segundo numero entero o decimal   ";cin>>y;
    
    suma= x+y;
    resta= x-y;
    multiplicacion= x*y;
    division= x/y;
    
    cout<<"la suma es: "<< x<<"+"<< y<<" = "<<suma<<endl;
    cout<<"la resta es: "<< x<<"-"<< y<<" = "<<resta<<endl;
    cout<<"la multiplicacion es: "<< x<<"*"<< y<<" = "<<multiplicacion<<endl;
    cout<<"la division es: "<< x<<"/"<< y<<" = "<<division<<endl;
    
    
    
    
    
    
    
    return 0;
}