/******************************************************************************

                              Online C++ Compiler.
                              
               Generar un programa que realice lo siguiente:
               
1. Que pida el ingreso de un valor (edad)
2. Que determine si es mayor de edad o menor de edad
3. Que lo muestre en pantalla con su respectivo enunciado, si es mayor de edad o no.

*******************************************************************************/

#include <stdio.h>
#include <iostream>

int main()

{
    int edad;
   std::cout<<"Ingrese su edad:";
    std::cin>>edad;
    
    if(edad >=18) {
        std::cout <<"Usted es mayor de edad." <<std::endl;
    } else {
        std::cout <<"usted es menor de edad." <<std::endl;
    }
    
    return 0;
    
}